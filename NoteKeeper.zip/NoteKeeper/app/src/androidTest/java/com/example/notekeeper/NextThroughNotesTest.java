package com.example.notekeeper;

import org.junit.Rule;
import org.junit.Test;


public class NextThroughNotesTest {
    @Rule
    //public ActivityTestRule<MainActivity> mActivityTestRule =
      //      new ActivivtyTestRule(MainActivity.class);

    @Test

    public void NextThroughNotes(){

    }
}